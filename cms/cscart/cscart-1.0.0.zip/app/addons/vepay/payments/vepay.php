<?php

defined('BOOTSTRAP') or die('Access denied');

function makeRequest($url, $postData, $id, $token)
{
    $curl = curl_init();

    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json',
        'X-Login: ' . $id,
        'X-Token: ' . $token
    ]);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

    $response = curl_exec($curl);

    curl_close($curl);

    return json_decode($response, true);
}

if (defined('PAYMENT_NOTIFICATION')) {
    if ($mode === 'process') {
        $extId = $_REQUEST['extid'];
        $id = $_REQUEST['id'];
        $sum = $_REQUEST['sum'];
        $status = $_REQUEST['status'];
        $key = $_REQUEST['key'];

        $payment_id = db_get_field("SELECT payment_id FROM ?:orders WHERE order_id = ?i", intval($extId));
        $processor_data = fn_get_processor_data($payment_id);

        $callbackToken = $processor_data['processor_params']['vepay_callback_token'];

        $checkKey = md5($extId . $id . $sum . $status . $callbackToken);

        if ($checkKey === $key) {
            $order_info = fn_get_order_info($extId);

            if (intval($status) === 1) {
                $pp_response['order_status'] = 'P';
                $pp_response['reason_text'] = __('approved');
            } else {
                $pp_response['order_status'] = 'F';
                $pp_response['reason_text'] = __('text_transaction_cancelled');
            }
        } else {
            $pp_response['order_status'] = 'F';
            $pp_response['reason_text'] = __('control_summ_wrong');
        }

        $extId = intval($extId);
        fn_finish_payment($extId, $pp_response);
        die('OK' . $extId);
    } else if ($mode === 'fail') {
        $extId = intval($_REQUEST['extid']);

        $pp_response = [
            'order_status' => STATUS_CANCELED_ORDER,
            'reason_text' => __('text_transaction_cancelled'),
        ];
        fn_finish_payment($extId, $pp_response, false);
        fn_order_placement_routines('route', $extId);
    }
} else {
    $amount = $order_info['total'];
    $extId = strval($order_id);
    $descript = 'Заказ №' . $order_id;
    $merchId = $processor_data['processor_params']['vepay_merch_id'];
    $merchToken = $processor_data['processor_params']['vepay_merch_token'];

    $params = [
        'amount' => $amount,
        'extid' => $extId,
        'descript' => $descript,
        'timeout' => 50,
        'successurl' => fn_url() . '?dispatch=checkout.complete',
        'failurl' => fn_url() . '?dispatch=payment_notification.fail&payment=vepay&extid=' . $extId,
    ];

    $params = json_encode($params);
    $token = sha1(sha1($merchToken) . sha1($params));

    $response = makeRequest('https://api.vepay.online/merchant/pay', $params, $merchId, $token);

    $paymentUrl = $response['url'];

    fn_change_order_status($order_id, 'O');
    fn_create_payment_form($paymentUrl, [], 'Vepay', false);
}
