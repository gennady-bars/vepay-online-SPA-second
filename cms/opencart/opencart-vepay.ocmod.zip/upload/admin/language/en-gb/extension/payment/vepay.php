<?php

$_['heading_title'] = 'Vepay';

$_['text_payment'] = 'Расширения';
$_['text_edit'] = 'Редактирование Vepay';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_success'] = 'Настройки модуля оплаты Vepay обновлены!';

$_['entry_merch_id'] = 'ID магазина';
$_['entry_merch_token'] = 'Токен магазина';
$_['entry_order_status'] = 'Статус заказа после оплаты';
$_['entry_status'] = 'Статус';
$_['entry_callback_url'] = 'Адрес обратного запроса';
$_['entry_callback_token'] = 'Ключ обратного запроса';

$_['help_callback_url'] = 'Укажите его в личном кабинете';

$_['error_permission'] = 'Внимание: У Вас недостаточно прав для управления модулем оплаты Vepay!';
$_['error_merch_id'] = 'Требуется указать ID магазина!';
$_['error_merch_token'] = 'Требуется указать токен магазина!';
$_['error_callback_token'] = 'Требуется указать ключ обратного запроса!';
