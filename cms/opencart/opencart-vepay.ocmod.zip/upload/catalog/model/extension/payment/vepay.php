<?php

class ModelExtensionPaymentVepay extends Model
{
    public function getMethod($address, $total)
    {
        $this->load->language('extension/payment/vepay');

        if ($this->config->get('payment_vepay_status')) {
            $status = true;
        } else {
            $status = false;
        }

        $methodData = [];
        if ($status) {
            $methodData = [
                'code' => 'vepay',
                'title' => $this->language->get('text_title'),
            ];
        }

        return $methodData;
    }
}