<?php

class ControllerExtensionPaymentVepay extends Controller
{
    public function index()
    {
        $data['button_confirm'] = $this->language->get('button_confirm');

        $this->load->model('checkout/order');
        $orderInfo = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        $merchId = $this->config->get('payment_vepay_merch_id');
        $merchToken = $this->config->get('payment_vepay_merch_token');

        $params = [
            'amount' => $this->currency->format($orderInfo['total'], 'RUB', false, false),
            'extid' => strval($this->session->data['order_id']),
            'descript' => 'Покупка в ' . $this->config->get('config_name'),
            'timeout' => 50,
            'successurl' => $this->url->link('extension/payment/vepay/success'),
            'failurl' => $this->url->link('extension/payment/vepay/fail'),
        ];

        $params = json_encode($params);
        $token = sha1(sha1($merchToken) . sha1($params));
        $response = $this->makeRequest('https://api.vepay.online/merchant/pay', $params, $merchId, $token);

        $data['payment_url'] = isset($response['url']) ? $response['url'] : null;

        return $this->load->view('extension/payment/vepay', $data);
    }

    public function fail()
    {
        return $this->response->redirect($this->url->link('checkout/checkout', '', true));
    }

    public function success()
    {
        return $this->response->redirect($this->url->link('checkout/success', '', true));
    }

    public function result()
    {
        $this->log->write($this->request->get);

        $callbackToken = $this->config->get('payment_vepay_callback_token');

        $extId = $this->request->get['extid'];
        $id = $this->request->get['id'];
        $sum = $this->request->get['sum'];
        $status = $this->request->get['status'];
        $key = $this->request->get['key'];

        $checkKey = md5($extId . $id . $sum . $status . $callbackToken);
        if ($key === $checkKey && intval($status) === 1) {
            $newOrderStatusId = $this->config->get('payment_vepay_order_status_id');
            $this->model_checkout_order->addOrderHistory($extId, $newOrderStatusId);

            return true;
        } else{
            $this->log->write('Не удалось провести платеж #' . $extId);
            return false;
        }
    }

    private function makeRequest($url, $postData, $id, $token)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json', 'X-Login: ' . $id, 'X-Token: ' . $token]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($curl);

        curl_close($curl);

        return json_decode($response, true);
    }
}