<?php

$className = "vepay";
$paymentName = "VEPAY";

include "standalone.php";

$objectTypesCollection = umiObjectTypesCollection::getInstance();
$internalTypeId = $objectTypesCollection->getTypeIdByGUID("emarket-paymenttype");

$sel = new selector('objects');
$sel->types('object-type')->id($internalTypeId);
$sel->where('class_name')->equals($className);
$sel->limit(0, 1);

$bAdd = $sel->length() == 0;
if ($bAdd) {
    $objectsCollection = umiObjectsCollection::getInstance();

    $parentTypeId = $objectTypesCollection->getTypeIdByGUID("emarket-payment");

    $typeId = $objectTypesCollection->addType($parentTypeId, $paymentName);
    $objectType = $objectTypesCollection->getType($typeId);

    $internalObjectId = $objectsCollection->addObject($paymentName, $internalTypeId);
    $internalObject = $objectsCollection->getObject($internalObjectId);
    $internalObject->setValue("class_name", $className);

    $internalObject->setValue("payment_type_id", $typeId);
    $internalObject->setValue("payment_type_guid", "user-emarket-payment-" . $typeId);
    $internalObject->commit();

    $internalObject->setValue("payment_type_id", $typeId);
    $internalObject->setValue("payment_type_guid", "user-emarket-payment-" . $typeId);
    $internalObject->commit();

    $type = $objectTypesCollection->getType($typeId);
    $type->setGUID($internalObject->getValue("payment_type_guid"));
    $type->commit();

    echo "Готово!";
} else {
    echo "Способ оплаты с классом " . $className . " уже существует";
}