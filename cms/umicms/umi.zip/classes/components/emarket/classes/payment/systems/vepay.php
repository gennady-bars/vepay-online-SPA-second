<?php

class vepayPayment extends payment
{
    public function validate()
    {
        return true;
    }

    public function process($template = 'default')
    {
        if (!isset($template))
            $template = 'default';

        $this->order->order();

        $merchId = $this->object->getValue('merch_id');
        $merchToken = $this->object->getValue('merch_token');

        $sum = (float)$this->order->getActualPrice();

        $params = [
            'amount' => $sum,
            'extid' => strval($this->order->getId()),
            'descript' => 'Заказ #' . $this->order->getNumber(),
            'timeout' => 50,
            'successurl' => $this->getHost() . '/emarket/purchase/result/successful',
            'failurl' => $this->getHost() . '/emarket/purchase/result/failed',
        ];
        $params = json_encode($params);

        $token = sha1(sha1($merchToken) . sha1($params));
        $response = $this->makeRequest('https://api.vepay.online/merchant/pay', $params, $merchId, $token);

        $paymentUrl = $response['url'];
        $params = [
            'paymentUrl' => $paymentUrl,
        ];

        $this->order->setPaymentStatus('initialized');

        list($formBlock) = def_module::loadTemplates('emarket/payment/vepay/' . $template, 'form_block');

        return def_module::parseTemplate($formBlock, $params);
    }

    public function poll()
    {
        $extId = getRequest('extid');
        $id = getRequest('id');
        $sum = getRequest('sum');
        $status = getRequest('status');
        $key = getRequest('key');

        $checkKey = md5($extId . $id . $sum . $status . $this->object->getValue('callback_token'));
        if ($checkKey === $key) {
            if (intval($status) === 1) {
                $this->order->setPaymentStatus('accepted');
            } else {
                $this->order->setPaymentStatus('declined');
            }
        } else {
            $this->order->setPaymentStatus('declined');
        }

        $this->order->commit();
        $this->returnJson(['result' => true]);
    }

    public static function getOrderId()
    {
        $extId = getRequest('extid');
        return intval($extId);
    }

    function returnJson($arr)
    {
        $result = json_encode($arr);

        $buffer = outputBuffer::current();
        $buffer->clear();
        $buffer->contentType('application/json');
        $buffer->push($result);
        $buffer->end();
    }

    private function getHost()
    {
        $cmsController = cmsController::getInstance();
        $strProtocol = !empty($_SERVER['HTTPS']) ? 'https://' : 'http://';
        return $strProtocol . $cmsController->getCurrentDomain()->getHost();
    }

    private function makeRequest($url, $postData, $id, $token)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Login: ' . $id,
            'X-Token: ' . $token
        ]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($curl);

        curl_close($curl);

        return json_decode($response, true);
    }
}

;
