<?php
namespace Magento\VepayPaymentGateway\Controller\Request;

use \Magento\Framework\App\Action\Context;
use \Magento\Framework\App\Request\Http;
use \Magento\Sales\Model\OrderFactory;
use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Sales\Model\Order;

class callback extends \Magento\Framework\App\Action\Action
{
    protected $urlBuilder;
    public $request;
    public $storeManager;
    public $objectManager;
    public $baseurl;
    public $order;
    public $orderFactory;
    protected $resultPageFactory;
    public $scope;

    public function __construct(
        Context $context,
        Http $request,
        PageFactory $resultPageFactory,
        OrderFactory $orderFactory,
        ScopeConfigInterface $scopeConfig
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->orderFactory = $orderFactory;
        $this->request = $request;
        $this->scope = $scopeConfig;
        return parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->request->getParams();

        $extId = $params['extid'];
        $order = \Magento\Framework\App\ObjectManager::getInstance()->create('\Magento\Sales\Model\Order')->loadByIncrementId((int)$extId);
        if ($order) {
            echo $this->_processOrder($order, $params);
        } else {
            echo 'order id incorrect';
        }
        exit;
    }

    protected function _processOrder(\Magento\Sales\Model\Order $order, $params)
    {
        $extId = $params['extid'];
        $id = $params['id'];
        $sum = $params['sum'];
        $status = $params['status'];
        $key = $params['key'];

        $callbackToken = $this->getCfg('callback_token');

        $checkKey = md5($extId . $id . $sum . $status . $callbackToken);
        if ($checkKey === $key) {
            if (intval($status) === 1) {
                $order->setStatus(Order::STATE_COMPLETE);
                $order->setState(Order::STATE_COMPLETE);
                $order->save();
                return 'ok';
            } else {
                $order->setStatus(Order::STATE_CANCELED);
                $order->setState(Order::STATE_CANCELED);
                $order->save();
                return 'bad payment status';
            }
        } else {
            $order->setStatus(Order::STATE_CANCELED);
            $order->setState(Order::STATE_CANCELED);
            $order->save();
            return 'signature invalid';
        }
    }

    private function getCfg($k)
    {
        return $this->scope->getValue('payment/vepay_gateway/'.$k,\Magento\Store\Model\ScopeInterface::SCOPE_STORES);
    }
}
