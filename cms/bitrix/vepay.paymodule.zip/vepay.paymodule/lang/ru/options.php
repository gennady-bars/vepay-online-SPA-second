<?
global $MESS;

$MESS['VEPAY_merch_id'] = 'ID магазина';
$MESS['VEPAY_merch_token'] = 'Токен магазина';
$MESS['VEPAY_callback_token'] = 'Ключ обратного запроса';
$MESS['VEPAY_success_url'] = 'Success URL';
$MESS['VEPAY_fail_url'] = 'Fail URL';
$MESS['VEPAY_description'] = 'Описание заказа';

$MESS['VEPAY_D_success_url'] = 'Ссылка на страницу успешной оплаты';
$MESS['VEPAY_D_fail_url'] = 'Ссылка на страницу успешной оплаты';
$MESS['VEPAY_D_description'] = 'Например "Оплата заказа из магазина Цветов"';

$MESS['VEPAY_PROP'] = 'Настройка Vepay';
