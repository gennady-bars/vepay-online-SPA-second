<?
global $MESS;

$MESS['DEVELOPER'] = 'Vepay';
$MESS['DEVELOPER_SITE'] = 'https://vepay.online/';

$MESS['VEPAY_MODULE_NAME'] = 'Платежная система Vepay';
$MESS['VEPAY_MODULE_DESCRIPTION'] = 'универсальное платежное решение';

$MESS['VEPAY_D'] = 'доступ закрыт';
$MESS['VEPAY_R'] = 'доступ открыт';
$MESS['VEPAY_W'] = 'полный доступ';
