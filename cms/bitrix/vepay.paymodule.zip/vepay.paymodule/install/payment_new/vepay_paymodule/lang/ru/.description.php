<?
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/lang/ru/.description.php')) {
    include($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/lang/ru/.description.php');
}

