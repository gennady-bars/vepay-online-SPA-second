<?
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/handler.php')) {
    include($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/handler.php');
}
