<?
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/template/lang/ru/template_all.php')) {
    include($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/vepay.paymodule/handlers/vepay/template/lang/ru/template_all.php');
}
