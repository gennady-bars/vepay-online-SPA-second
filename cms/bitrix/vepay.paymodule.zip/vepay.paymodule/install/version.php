<?
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2020-02-24 12:00:00"
);
