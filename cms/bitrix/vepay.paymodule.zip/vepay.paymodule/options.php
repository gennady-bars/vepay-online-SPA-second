<?

$module_id = "vepay.paymodule";

if (!$USER->CanDoOperation('vepay.paymodule.settings')) {
    $APPLICATION->AuthForm(GetMessage("ACCESS_DENIED"));
}

CModule::IncludeModule("iblock");
CModule::IncludeModule('vepay.paymodule');

IncludeModuleLangFile($_SERVER["DOCUMENT_ROOT"] . BX_ROOT . "/modules/main/options.php");
IncludeModuleLangFile(__FILE__);

use Bitrix\Main\SiteTable;

$siteList = array();
$siteIterator = SiteTable::getList(array(
    'select' => array('LID', 'NAME'),
    'order' => array('SORT' => 'ASC')
));

while ($oneSite = $siteIterator->fetch()) {
    $siteList[] = array('ID' => $oneSite['LID'], 'NAME' => $oneSite['NAME']);
}

unset($oneSite, $siteIterator);
$siteCount = count($siteList);

$arAllOptions = Array(
    Array("merch_id_", GetMessage('VEPAY_merch_id'), array("text"), "", GetMessage('VEPAY_D_merch_id')),
    Array("merch_token_", GetMessage('VEPAY_merch_token'), array("text"), "", GetMessage('VEPAY_D_merch_token')),
    Array("callback_token_", GetMessage('VEPAY_callback_token'), array("text"), "", GetMessage('VEPAY_D_callback_token')),
    Array("success_url_", GetMessage('VEPAY_success_url'), array("text"), "", GetMessage('VEPAY_D_success_url')),
    Array("fail_url_", GetMessage('VEPAY_fail_url'), array("text"), "", GetMessage('VEPAY_D_fail_url')),
    Array("description_", GetMessage('VEPAY_description'), array("text"), "", GetMessage('VEPAY_D_description')),
);

$aTabs = array(
    array("DIV" => "edit1", "TAB" => GetMessage('VEPAY_PROP'), "ICON" => "vepay_settings", "TITLE" => GetMessage('VEPAY_PROP_TITLE')),
    array("DIV" => "edit2", "TAB" => GetMessage("MAIN_TAB_RIGHTS"), "ICON" => "vepay_settings", "TITLE" => GetMessage("MAIN_TAB_RIGHTS_TITLE")),
);

$tabControl = new CAdminTabControl("tabControl", $aTabs);

if ($REQUEST_METHOD == "POST" && strlen($Update . $Apply . $RestoreDefaults) > 0 && check_bitrix_sessid()) {
    if (strlen($RestoreDefaults) > 0) {
        COption::RemoveOption('vepay.paymodule');
        $z = CGroup::GetList($v1 = "id", $v2 = "asc", array("ACTIVE" => "Y", "ADMIN" => "N"));
        while ($zr = $z->Fetch())
            $APPLICATION->DelGroupRight($module_id, array($zr["ID"]));
    } else {
        foreach ($siteList as $site) {
            COption::SetOptionString('vepay.paymodule', 'merch_id_' . $site['ID'],
                $_POST['merch_id_' . $site['ID']]);
            COption::SetOptionString('vepay.paymodule', 'merch_token_' . $site['ID'],
                $_POST['merch_token_' . $site['ID']]);
            COption::SetOptionString('vepay.paymodule', 'callback_token_' . $site['ID'],
                $_POST['callback_token_' . $site['ID']]);
            COption::SetOptionString('vepay.paymodule', 'success_url_' . $site['ID'],
                $_POST['success_url_' . $site['ID']]);
            COption::SetOptionString('vepay.paymodule', 'fail_url_' . $site['ID'],
                $_POST['fail_url_' . $site['ID']]);
            COption::SetOptionString('vepay.paymodule', 'description_' . $site['ID'],
                $_POST['description_' . $site['ID']]);
        }
    }
}

$tabControl->Begin();

?>

<form method="POST" enctype="multipart/form-data"
      action="<? echo $APPLICATION->GetCurPage() ?>?mid=<?= htmlspecialcharsbx($mid) ?>&amp;lang=<? echo LANG ?>"
      name="antispampro_settings">

    <?= bitrix_sessid_post(); ?>
    <?= $tabControl->BeginNextTab(); ?>

    <td colspan="2" align="center">
        <table cellspacing="0" cellpadding="0" border="0" class="internal" style="width: 85%;">
            <? foreach ($siteList as $site) { ?>
                <tr colspan="2" class="heading">
                    <td valign="top">
                        [<a href="site_edit.php?LID=<?= $site["ID"] ?>&lang=<?= LANGUAGE_ID ?>" title="<?= GetMessage("SALE_SITE_ALT") ?>"><? echo $site["ID"] ?></a>] <? echo($site["NAME"]) ?>
                    </td>
                </tr>
                <tr colspan="2">
                    <td>
                        <table style="width: 100%;">
                            <? foreach ($arAllOptions as $arOption):
                                $val = COption::GetOptionString("vepay.paymodule", $arOption[0] . $site['ID'], $arOption[3]);
                                $type = $arOption[2]; ?>
                                <tr>
                                    <td valign="top" width="25%" style="vertical-align: middle;">
                                        <? if ($type[0] == "checkbox")
                                            echo "<label for=\"" . htmlspecialcharsbx($arOption[0]) . "\">" . $arOption[1] . "</label>";
                                        else
                                            echo $arOption[1]; ?>:
                                    </td>
                                    <td valign="top" width="70%">
                                        <? if ($type[0] == "checkbox"): ?>
                                            <input type="checkbox"
                                                   name="<? echo htmlspecialcharsbx($arOption[0]) . $site['ID'] ?>"
                                                   id="<? echo htmlspecialcharsbx($arOption[0]) ?>"
                                                   value="Y"<? if ($val == "Y") echo " checked"; ?> />
                                            <p><small><?= $arOption[4] ?></small></p>
                                        <? elseif ($type[0] == "text"): ?>
                                            <input type="text" size="<? echo $type[1] ?>" maxlength="2550"
                                                   value="<? echo htmlspecialcharsbx($val) ?>"
                                                   name="<? echo htmlspecialcharsbx($arOption[0]) . $site['ID'] ?>"
                                                   style="width:90%;"/>
                                            <p><small><?= $arOption[4] ?></small></p>
                                        <? elseif ($type[0] == "textarea"): ?>
                                            <textarea rows="<? echo $type[1] ?>" cols="<? echo $type[2] ?>"
                                                      name="<? echo htmlspecialcharsbx($arOption[0]) . $site['ID'] ?>"
                                                      style="width:90%;"><? echo htmlspecialcharsbx($val) ?></textarea>
                                        <? endif; ?>
                                    </td>
                                </tr>
                            <? endforeach; ?>
                        </table>
                    </td>
                </tr>
            <? } ?>
        </table>
    </td>

    <?
    $tabControl->BeginNextTab();

    require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/admin/group_rights.php");

    $tabControl->Buttons();
    ?>

    <script language="JavaScript">
        function confirmRestoreDefaults() {
            return confirm('<?echo AddSlashes(GetMessage("MAIN_HINT_RESTORE_DEFAULTS_WARNING"))?>');
        }
    </script>

    <input type="submit" name="Update" value="<? echo GetMessage("MAIN_SAVE") ?>">
    <input type="hidden" name="Update" value="Y">
    <input type="reset" name="reset" value="<? echo GetMessage("MAIN_RESET") ?>">
    <input type="submit" name="RestoreDefaults" title="<? echo GetMessage("MAIN_HINT_RESTORE_DEFAULTS") ?>"
           OnClick="return confirmRestoreDefaults();" value="<? echo GetMessage("MAIN_RESTORE_DEFAULTS") ?>">
    <? $tabControl->End(); ?>

</form>