<?php

namespace Sale\Handlers\PaySystem;

use Bitrix\Main;
use Bitrix\Main\Error;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Request;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Type\DateTime;
use Bitrix\Sale\PaySystem;
use Bitrix\Sale\Payment;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Sale\BasketItem;
use Bitrix\Sale\Shipment;

class vepay_paymoduleHandler extends PaySystem\ServiceHandler
{
    public static function getIndicativeFields()
    {
        return array('BX_HANDLER' => 'VEPAY');
    }

    public function getCurrencyList()
    {
        return array('RUB');
    }

    static protected function isMyResponseExtended(Request $request, $paySystemId)
    {
        return true;
    }

    public function getPaymentIdFromRequest(Request $request)
    {
        return $request->get('extid');
    }

    public function initiatePay(Payment $payment, Request $request = null)
    {
        $settings = $this->getParamsBusValue($payment);

        $orderId = $settings["OrderID"];

        $merchId = Option::get('vepay.paymodule', 'merch_id_' . SITE_ID);
        $merchToken = Option::get('vepay.paymodule', 'merch_token_' . SITE_ID);
        $successUrl = Option::get('vepay.paymodule', 'success_url_' . SITE_ID);
        $failUrl = Option::get('vepay.paymodule', 'fail_url_' . SITE_ID);
        $desc = Option::get('vepay.paymodule', 'description_' . SITE_ID);

        $params = [
            'amount' => number_format($settings["OrderSum"], 2, '.', ''),
            'extid' => strval($orderId),
            'descript' => $desc,
            'timeout' => 50,
            'successurl' => $successUrl,
            'failurl' => $failUrl,
        ];

        $params = json_encode($params);
        $token = sha1(sha1($merchToken) . sha1($params));
        $response = $this->makeRequest('https://api.vepay.online/merchant/pay', $params, $merchId, $token);

        $params = [
            'payment_url' => isset($response['url']) ? $response['url'] : null
        ];

        $this->setExtraParams($params);
        return $this->showTemplate($payment, 'template_all');
    }

    private function makeRequest($url, $postData, $id, $token)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json', 'X-Login: ' . $id, 'X-Token: ' . $token]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($curl);

        curl_close($curl);

        return json_decode($response, true);
    }

    public function processRequest(Payment $payment, Request $request)
    {
        $result = new PaySystem\ServiceResult();

        $callbackToken = Option::get('vepay.paymodule', 'callback_token_' . SITE_ID);

        $extId = $request->get('extid');
        $id = $request->get('id');
        $sum = $request->get('sum');
        $status = $request->get('status');
        $key = $request->get('key');

        $checkKey = md5($extId . $id . $sum . $status . $callbackToken);
        if ($key === $checkKey && intval($status) === 1) {
            $fields = array(
                "PS_STATUS" => "Y",
                "PS_STATUS_CODE" => $extId,
                "PS_STATUS_DESCRIPTION" => "-",
                "PS_STATUS_MESSAGE" => "-",
                "PS_SUM" => $sum,
                "PS_CURRENCY" => 'RUB',
                "PS_RESPONSE_DATE" => new DateTime(),
            );
            $result->setPsData($fields);
            $result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);
        } else {
            $errorMessage = Loc::getMessage('VEPAY_BAD_CHECK');

            $result->addError(new Error($errorMessage));
            PaySystem\ErrorLog::add(array(
                'ACTION' => 'processRequest',
                'MESSAGE' => $errorMessage
            ));
        }

        return $result;
    }
}
