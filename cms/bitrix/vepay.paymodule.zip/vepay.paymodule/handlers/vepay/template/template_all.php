<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);
?>

<form action="<?= $params["payment_url"] ?>" method="post" target="_blank" accept-charset="utf-8" class="mb-4">
    <input class="btn btn-primary" type="submit" value="<?= GetMessage("VEPAY_BTN_PAY") ?>">
</form>
