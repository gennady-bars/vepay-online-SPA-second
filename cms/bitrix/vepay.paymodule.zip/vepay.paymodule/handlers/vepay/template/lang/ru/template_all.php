<?php
$MESS['VEPAY_BTN_PAY'] = 'Оплатить';
