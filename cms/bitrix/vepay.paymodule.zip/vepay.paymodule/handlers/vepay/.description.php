<?php

use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);
$mod_lang = "VEPAY_";
$data = array(
    'NAME' => Loc::getMessage($mod_lang . 'NamePayment1'),
    'SORT' => 500,
    'CODES' => array(
        'OrderID' => array(
            "NAME" => Loc::getMessage($mod_lang . 'OrderID'),
            'SORT' => 300,
            'GROUP' => Loc::getMessage($mod_lang . 'ORDER_INFO'),
            'DEFAULT' => array(
                'PROVIDER_KEY' => 'PAYMENT',
                'PROVIDER_VALUE' => 'ID'
            )
        ),
        'OrderSum' => array(
            "NAME" => Loc::getMessage($mod_lang . 'OrderSum'),
            'SORT' => 325,
            'GROUP' => Loc::getMessage($mod_lang . 'ORDER_INFO'),
            'DEFAULT' => array(
                'PROVIDER_KEY' => 'PAYMENT',
                'PROVIDER_VALUE' => 'SUM'
            )
        ),
    )
);
