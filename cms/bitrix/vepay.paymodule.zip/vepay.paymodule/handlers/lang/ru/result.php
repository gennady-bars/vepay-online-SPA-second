<?php

global $MESS;

$MESS['VEPAY_CHECK_SUCCESS'] = 'Заказ можно оплатить';
$MESS['VEPAY_PAY_SUCCESS'] = 'Заказ успешно оплачен';
$MESS['VEPAY_UNKNOWN_METHOD'] = 'Неизвестный метод';
