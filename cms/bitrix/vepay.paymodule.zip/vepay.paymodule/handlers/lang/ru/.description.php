<?php
$mod_lang = "VEPAY_";

global $MESS;
$MESS[$mod_lang."NamePayment1"] = "Vepay";

$MESS[$mod_lang."OrderID"] = "Номер заказа";
$MESS[$mod_lang."OrderSum"] = "Стоимость заказа";

$MESS[$mod_lang."ORDER_INFO"] = "Информация о заказе";
