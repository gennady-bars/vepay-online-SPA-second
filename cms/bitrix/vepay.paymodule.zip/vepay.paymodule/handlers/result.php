<?

use \Bitrix\Main\Application;
use \Bitrix\Main\Localization\Loc;

define("NO_KEEP_STATISTIC", true);
define("NOT_CHECK_PERMISSIONS", true);

define("STOP_STATISTICS", true);
define('NO_AGENT_CHECK', true);
define("DisableEventsCheck", true);
require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

if (CModule::IncludeModule("sale")) {
    $context = Application::getInstance()->getContext();
    $request = $context->getRequest();

    $item = Bitrix\Sale\PaySystem\Manager::searchByRequest($request);
    $service = new Bitrix\Sale\PaySystem\Service($item);

    $method = $request->get('method');
    $result = $service->processRequest($request);
    if ($result->isSuccess()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }

}
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/epilog_after.php");
