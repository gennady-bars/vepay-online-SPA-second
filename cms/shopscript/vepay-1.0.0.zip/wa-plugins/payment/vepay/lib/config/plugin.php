<?php

return [
    'name' => 'Vepay',
    'description' => 'Платежная система Vepay',
    'icon' => 'img/unitpay16.png',
    'logo' => 'img/unitpay.png',
    'version' => '1.0.0',
    'locale' => ['ru_RU',],
    'type' => waPayment::TYPE_ONLINE,
];
