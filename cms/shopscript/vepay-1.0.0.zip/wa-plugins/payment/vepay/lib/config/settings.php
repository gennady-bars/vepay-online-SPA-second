<?php

return [
    'vepay_merch_id' => [
        'value' => '',
        'title' => 'Merch Id',
        'description' => 'Скопируйте Merch Id с вашего аккаунта в системе VEPAY',
        'control_type' => 'input',
        'class' => 'keys',
    ],
    'vepay_merch_token' => [
        'value' => '',
        'title' => 'Merch Token',
        'description' => 'Скопируйте Merch Token с вашего аккаунта в системе VEPAY',
        'control_type' => 'input',
        'class' => 'keys',
    ],
    'vepay_callback_token' => [
        'value' => '',
        'title' => 'Callback Token',
        'description' => 'Скопируйте Ключ обратного запроса с вашего аккаунта в системе VEPAY',
        'control_type' => 'input',
        'class' => 'keys',
    ],
    'vepay_callback_url' => [
        'value' => wa()->getRouting()->getDomain() . '/payments.php/vepay',
        'title' => 'Callback Url',
        'description' => 'Укажите этот адрес в поле "Адрес для обратного запроса" в системе VEPAY',
        'control_type' => 'input',
        'readonly' => true,
        'class' => 'keys',
    ],
];
