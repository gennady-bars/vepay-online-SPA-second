<?php

class vepayPayment extends waPayment implements waIPayment
{
    const DELIMITER = ':';

    protected $order_id;

    public function allowedCurrency()
    {
        return [
            'RUB',
        ];
    }

    public function payment($payment_form_data, $order_data, $auto_submit = false)
    {
        $result = null;
        $order = waOrder::factory($order_data);

        $amount = $order->total;
        $extId = $order->id . vepayPayment::DELIMITER . $this->merchant_id;
        $descript = $order->description;

        $params = [
            'amount' => $amount,
            'extid' => strval($extId),
            'descript' => $descript,
            'timeout' => 50,
            'successurl' => $this->getAdapter()->getBackUrl(waAppPayment::URL_SUCCESS),
            'failurl' => $this->getAdapter()->getBackUrl(waAppPayment::URL_FAIL),
        ];

        $params = json_encode($params);

        $token = sha1(sha1($this->vepay_merch_token) . sha1($params));
        $response = $this->makeRequest('https://api.vepay.online/merchant/pay', $params, $this->vepay_merch_id, $token);

        $paymentUrl = $response['url'];

        $view = wa()->getView();
        $view->assign('payment_url', $paymentUrl);

        return $view->fetch($this->path . '/templates/payment.html');
    }

    protected function callbackInit($request)
    {
        list($this->order_id, $this->merchant_id) = explode(vepayPayment::DELIMITER, $request['extid'], 2);
        return parent::callbackInit($request);
    }

    protected function callbackHandler($data)
    {
        $extId  = $data['extid'];
        $id     = $data['id'];
        $sum    = $data['sum'];
        $status = $data['status'];
        $key    = $data['key'];

        $checkKey = md5( $extId . $id . $sum . $status . $this->vepay_callback_token );
        if ( $checkKey === $key ) {
            if ( intval( $status ) === 1 ) {
                $result = $this->pay($data);
            } else {
                $result = ['result' => ['message' => 'Произошла ошибка при обработке платежа']];
            }
        } else {
            $result = ['result' => ['message' => 'Произошла ошибка при обработке платежа']];
        }

        return $this->returnJson($result);
    }

    public function pay($params)
    {
        $transaction_data = $this->formalizeData($params);
        $transaction_data = $this->saveTransaction($transaction_data, $params);

        $result = $this->execAppCallback(self::CALLBACK_PAYMENT, $transaction_data);

        if (empty($result['result'])) {
            $message = !empty($result['error']) ? $result['error'] : 'wa transaction error';
            return ['error' => ['message' => $message]];
        }

        return ['result' => ['message' => 'Запрос успешно обработан']];
    }

    public function formalizeData($params)
    {
        $transaction_data = parent::formalizeData($params);
        $transaction_data['order_id'] = $this->order_id;
        $transaction_data['amount'] = $params['sum'];
        $transaction_data['native_id'] = $params['id'];
        $transaction_data['type'] = self::OPERATION_CAPTURE;
        $transaction_data['state'] = self::STATE_CAPTURED;
        $transaction_data['currency_id'] = 'RUB';

        return $transaction_data;
    }

    protected function returnJson($message)
    {
        return [
            'header'  => [
                'Content-Type' => 'application/json'
            ],
            'message' => json_encode($message)
        ];
    }

    private function makeRequest( $url, $postData, $id, $token ) {
        $curl = curl_init();

        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $curl, CURLOPT_POSTFIELDS, $postData );
        curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'POST' );
        curl_setopt( $curl, CURLOPT_URL, $url );
        curl_setopt( $curl, CURLOPT_HEADER, false );
        curl_setopt( $curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Login: ' . $id,
            'X-Token: ' . $token
        ] );
        curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );

        $response = curl_exec( $curl );

        curl_close( $curl );

        return json_decode( $response, true );
    }
}