<?php

class vepayvepayModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $cart = $this->context->cart;

        if ($cart->id_customer == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $customer = new Customer((int)$cart->id_customer);

        if (!Validate::isLoadedObject($customer))
            Tools::redirect('index.php?controller=order&step=1');

        $currency = new Currency((int)$cart->id_currency);
        $total = (float)$cart->getOrderTotal(true, Cart::BOTH);

        $this->module->validateOrder($cart->id, Configuration::get('VEPAY_OS_NEEDPAY'), $total, $this->module->displayName, NULL, array(), (int)$currency->id, false, $customer->secure_key);

        $successUrl = $this->context->link->getPageLink(
            'order-confirmation',
            true,
            null,
            [
                'id_cart' => (int)$cart->id,
                'id_module' => (int)$this->module->id,
                'key' => $customer->secure_key
            ]
        );

        $failUrl = $this->context->link->getPageLink(
            'order-confirmation',
            true,
            null,
            [
                'id_cart' => (int)$cart->id,
                'id_module' => (int)$this->module->id,
                'key' => $customer->secure_key
            ]
        );

        $merchId = Configuration::get('VEPAY_MERCH_ID');
        $merchToken = Configuration::get('VEPAY_MERCH_TOKEN');
        $desc = 'Оплата заказа из магазина ' . Configuration::get('PS_SHOP_NAME');

        $params = [
            'amount' => $this->context->cart->getOrderTotal(),
            'extid' => strval(Order::getIdByCartId($cart->id)),
            'descript' => $desc,
            'timeout' => 50,
            'successurl' => $successUrl,
            'failurl' => $failUrl,
        ];

        $params = json_encode($params);
        $token = sha1(sha1($merchToken) . sha1($params));
        $response = $this->makeRequest('https://api.vepay.online/merchant/pay', $params, $merchId, $token);

        $paymentUrl = $response['url'];

        Tools::redirect($paymentUrl);
    }

    private function makeRequest($url, $postData, $id, $token)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, false);
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json',
            'X-Login: ' . $id,
            'X-Token: ' . $token
        ]);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);

        $response = curl_exec($curl);

        curl_close($curl);

        return json_decode($response, true);
    }
}