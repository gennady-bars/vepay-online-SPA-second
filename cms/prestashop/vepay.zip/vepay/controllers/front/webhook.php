<?php

class vepaywebhookModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_column_left = false;
    public $display_column_right = false;
    public $display_footer = false;

    public function postProcess()
    {
        $extId = $_GET['extid'];
        $id = $_GET['id'];
        $sum = $_GET['sum'];
        $status = $_GET['status'];
        $key = $_GET['key'];

        $callbackToken = Configuration::get('VEPAY_CALLBACK_TOKEN');

        $checkKey = md5($extId . $id . $sum . $status . $callbackToken);
        if ($checkKey === $key) {
            if (intval($status) === 1) {
                $result = $this->payment($extId);
            } else {
                $result = $this->error($extId);
            }
        } else {
            $result = [
                'error' => [
                    'message' => 'Неверная сигнатура'
                ]
            ];
        }

        echo json_encode($result);
        die();
    }

    function payment($extId)
    {
        $order = new Order($extId);

        if (is_null($order->id)) {
            $result = ['error' =>
                ['message' => 'заказа не существует']
            ];
        } else {
            $history = new OrderHistory();
            $history->id_order = $extId;
            $history->changeIdOrderState((int)Configuration::get('VEPAY_OS_PAYED'), (int)($extId));
            $history->addWithemail(true);

            $result = ['result' =>
                ['message' => 'Запрос успешно обработан']
            ];
        }

        return $result;
    }

    function error($extId)
    {
        $order = new Order($extId);

        if (is_null($order->id)) {
            $result = ['error' =>
                ['message' => 'заказа не существует']
            ];
        } else {

            $history = new OrderHistory();
            $history->id_order = $extId;
            $history->changeIdOrderState((int)Configuration::get('VEPAY_OS_ERROR_PAY'), (int)($id_order));
            $history->addWithemail(true);

            $result = ['result' =>
                ['message' => 'Запрос успешно обработан']
            ];
        }

        return $result;
    }
}
