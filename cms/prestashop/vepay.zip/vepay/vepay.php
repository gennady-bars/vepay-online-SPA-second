<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_'))
    exit;

class Vepay extends PaymentModule
{
    private $_html = '';
    private $_postErrors = array();

    public function __construct()
    {
        $this->name = 'vepay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
        $this->author = 'vepay';
        $this->need_instance = 1;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Vepay');
        $this->description = $this->l('Модуль для подключения платежной системы Vepay');
        $this->confirmUninstall = $this->l('Вы уверены что хотите деинсталлировать модуль?');

    }

    public function install()
    {
        if (Shop::isFeatureActive())
            Shop::setContext(Shop::CONTEXT_ALL);

        if (extension_loaded('curl') == false) {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

        if (!parent::install() ||
            !$this->registerHook('displayPayment') ||
            !$this->registerHook('paymentOptions') ||
            !$this->registerHook('paymentReturn') ||
            !Configuration::updateValue('VEPAY_OS_NEEDPAY', 800) ||
            !Configuration::updateValue('VEPAY_OS_PAYED', 801) ||
            !Configuration::updateValue('VEPAY_OS_ERROR_PAY', 802) ||
            !Configuration::updateValue('VEPAY_MERCH_ID', '') ||
            !Configuration::updateValue('VEPAY_MERCH_TOKEN', '') ||
            !Configuration::updateValue('VEPAY_CALLBACK_TOKEN', '') ||
            !Configuration::updateValue('VEPAY_CALLBACK_URL', '')
        )
            return false;


        $os = new OrderState((int)Configuration::get('VEPAY_OS_NEEDPAY'));
        $os->id = Configuration::get('VEPAY_OS_NEEDPAY');
        $os->force_id = true;
        $os->name = $this->multiLangField('Vepay Ожидает подтверждения платежа');
        $os->color = '#8A2BE2';
        $os->module_name = $this->name;
        $os->paid = false;
        $os->logable = false;
        $os->shipped = false;
        $os->delivery = false;
        $os->add();

        $os = new OrderState((int)Configuration::get('VEPAY_OS_PAYED'));
        $os->id = Configuration::get('VEPAY_OS_PAYED');
        $os->force_id = true;
        $os->name = $this->multiLangField('Vepay Платеж принят');
        $os->color = '#32CD32';
        $os->module_name = $this->name;
        $os->paid = true;
        $os->logable = false;
        $os->shipped = false;
        $os->delivery = false;
        $os->add();

        $os = new OrderState((int)Configuration::get('VEPAY_OS_ERROR_PAY'));
        $os->id = Configuration::get('VEPAY_OS_ERROR_PAY');
        $os->force_id = true;
        $os->name = $this->multiLangField('Vepay Ошибка оплаты');
        $os->color = '#DC143C';
        $os->module_name = $this->name;
        $os->paid = false;
        $os->logable = false;
        $os->shipped = false;
        $os->delivery = false;
        $os->add();

        return true;
    }

    public function uninstall()
    {
        $os = new OrderState((int)Configuration::get('VEPAY_OS_NEEDPAY'));
        $os->delete();

        $os = new OrderState((int)Configuration::get('VEPAY_OS_PAYED'));
        $os->delete();

        $os = new OrderState((int)Configuration::get('VEPAY_OS_ERROR_PAY'));
        $os->delete();


        if (!parent::uninstall() ||
            !Configuration::deleteByName('VEPAY_OS_NEEDPAY') ||
            !Configuration::deleteByName('VEPAY_OS_PAYED') ||
            !Configuration::deleteByName('VEPAY_OS_ERROR_PAY') ||
            !Configuration::deleteByName('VEPAY_MERCH_ID') ||
            !Configuration::deleteByName('VEPAY_MERCH_TOKEN') ||
            !Configuration::deleteByName('VEPAY_CALLBACK_TOKEN') ||
            !Configuration::deleteByName('VEPAY_CALLBACK_URL')
        )
            return false;

        return true;
    }

    private function _postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('VEPAY_MERCH_ID'))
                $this->_postErrors[] = $this->l('Необходимо ввести Merch Id');
            elseif (!Tools::getValue('VEPAY_MERCH_TOKEN'))
                $this->_postErrors[] = $this->l('Необходимо ввести Merch Token');
            elseif (!Tools::getValue('VEPAY_CALLBACK_TOKEN'))
                $this->_postErrors[] = $this->l('Необходимо ввести Callback Token');
        }
    }

    private function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('VEPAY_MERCH_ID', Tools::getValue('VEPAY_MERCH_ID'));
            Configuration::updateValue('VEPAY_MERCH_TOKEN', Tools::getValue('VEPAY_MERCH_TOKEN'));
            Configuration::updateValue('VEPAY_CALLBACK_TOKEN', Tools::getValue('VEPAY_CALLBACK_TOKEN'));
        }
        $this->_html .= $this->displayConfirmation($this->l('Настройки сохранены'));
    }

    public function getContent()
    {
        $this->_html = '';

        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors))
                $this->_postProcess();
            else
                foreach ($this->_postErrors as $err)
                    $this->_html .= $this->displayError($err);
        }

        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    public function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('settings')
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Merch Id'),
                        'desc' => "Скопируйте Merch Id с вашего аккаунта в системе VEPAY",
                        'name' => 'VEPAY_MERCH_ID',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Merch Token'),
                        'desc' => "Скопируйте Merch Token с вашего аккаунта в системе VEPAY",
                        'name' => 'VEPAY_MERCH_TOKEN',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Callback Token'),
                        'desc' => "Скопируйте Ключ обратного запроса с вашего аккаунта в системе VEPAY",
                        'name' => 'VEPAY_CALLBACK_TOKEN',
                        'required' => true
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->l('Callback Url'),
                        'desc' => "Укажите этот адрес в поле \"Адрес для обратного запроса\" в системе VEPAY",
                        'name' => 'VEPAY_CALLBACK_URL',
                        'required' => false,
                        'readonly' => true
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Save'),
                ]
            ],
        ];

        $helper = new HelperForm();
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'VEPAY_MERCH_ID' => Tools::getValue('VEPAY_MERCH_ID', Configuration::get('VEPAY_MERCH_ID')),
            'VEPAY_MERCH_TOKEN' => Tools::getValue('VEPAY_MERCH_TOKEN', Configuration::get('VEPAY_MERCH_TOKEN')),
            'VEPAY_CALLBACK_TOKEN' => Tools::getValue('VEPAY_CALLBACK_TOKEN', Configuration::get('VEPAY_CALLBACK_TOKEN')),
            'VEPAY_CALLBACK_URL' => $this->context->link->getModuleLink($this->name, 'webhook', [], true),
        );
    }

    public function hookPaymentOptions()
    {
        if (!$this->active) {
            return [];
        }

        $this->smarty->assign('module_dir', $this->_path);

        $vepay = new PaymentOption();
        $vepay->setAction($this->context->link->getModuleLink($this->name, 'vepay', [], true));
        $vepay->setCallToActionText('Vepay');
        $vepay->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/vepay.png'));

        return [$vepay];
    }

    public function hookPaymentReturn()
    {

    }

    public function hookDisplayPayment()
    {
        return $this->display(__FILE__, 'payment.tpl');
    }

    public function multiLangField($str)
    {
        $languages = Language::getLanguages(false);
        $data = array();
        foreach ($languages as $lang) {
            $data[$lang['id_lang']] = $str;
        }

        return $data;
    }
}
