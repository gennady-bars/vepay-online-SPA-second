<?php
/*
  Plugin Name: VEPAY
  Description: VEPAY Plugin for WooCommerce
  Version: 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'plugins_loaded', 'woocommerce_vepay', 0 );
function woocommerce_vepay() {
	load_plugin_textdomain( 'vepay', false, dirname( plugin_basename( __FILE__ ) ) . '/lang/' );

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}
	if ( class_exists( 'WC_VEPAY' ) ) {
		return;
	}

	class WC_VEPAY extends WC_Payment_Gateway {
		public function __construct() {
			$plugin_dir = plugin_dir_url( __FILE__ );

			$this->id         = 'vepay';
			$this->icon       = apply_filters( 'woocommerce_vepay_icon', $plugin_dir . 'vepay.png' );
			$this->has_fields = false;

			$this->init_form_fields();
			$this->init_settings();

			$this->merch_id       = $this->get_option( 'merch_id' );
			$this->merch_token    = $this->get_option( 'merch_token' );
			$this->callback_token = $this->get_option( 'callback_token' );
			$this->title          = 'VEPAY';
			$this->description    = __( 'Payment system VEPAY', 'vepay' );

			add_action( 'woocommerce_receipt_' . $this->id, [ $this, 'receipt_page' ] );
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [
				$this,
				'process_admin_options'
			] );
			add_action( 'woocommerce_api_wc_' . $this->id, [ $this, 'callback' ] );
		}

		public function admin_options() {
			?>

            <h3><?php _e( 'VEPAY', 'vepay' ); ?></h3>
            <p><?php _e( 'Setup payments parameters.', 'vepay' ) ?></p>

            <table class="form-table">
				<?php $this->generate_settings_html(); ?>
            </table>

			<?php
		}

		public function init_form_fields() {
			$this->form_fields = [
				'enabled'        => [
					'title'   => __( 'Enable/Disable', 'vepay' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enabled', 'vepay' ),
					'default' => 'yes',
				],
				'merch_id'       => [
					'title'       => __( 'MERCH ID', 'vepay' ),
					'type'        => 'text',
					'description' => __( 'Copy MERCH ID from your account page in VEPAY system', 'vepay' ),
					'default'     => '',
				],
				'merch_token'    => [
					'title'       => __( 'MERCH TOKEN', 'vepay' ),
					'type'        => 'text',
					'description' => __( 'Copy MERCH TOKEN from your account page in VEPAY system', 'vepay' ),
					'default'     => '',
				],
				'callback_token' => [
					'title'       => __( 'CALLBACK TOKEN', 'vepay' ),
					'type'        => 'text',
					'description' => __( 'Copy CALLBACK TOKEN from your account page in VEPAY system', 'vepay' ),
					'default'     => '',
				],
				'callback_url'   => [
					'title'             => __( 'CALLBACK URL', 'vepay' ),
					'type'              => 'text',
					'description'       => __( 'Provide this address in your account page in VEPAY system', 'vepay' ),
					'default'           => get_site_url() . '/?wc-api=wc_vepay',
					'custom_attributes' => [
						'readonly' => 'readonly',
					],
				],
			];
		}

		public function generate_form( $order_id ) {
			$order = new WC_Order( $order_id );

			$sum  = number_format( intval( $order->get_total() ), 2, '.', '' );
			$desc = __( 'Payment for order №', 'vepay' ) . $order_id;

			$params = [
				'amount'     => $sum,
				'extid'      => strval( $order_id ),
				'descript'   => $desc,
				'timeout'    => 50,
				'successurl' => $order->get_checkout_order_received_url(),
				'failurl'    => $order->get_cancel_order_url(),
			];

			$params   = json_encode( $params );
			$token    = sha1( sha1( $this->merch_token ) . sha1( $params ) );
			$response = $this->makeRequest( 'https://api.vepay.online/merchant/pay', $params, $this->merch_id, $token );

			$paymentUrl = $response['url'];

			return '<form action="' . $paymentUrl . '">' .
			       '<button type="submit" class="button alt">' . __( 'Pay', 'vepay' ) . '</button>' .
			       '</form>';
		}

		function process_payment( $order_id ) {
			$order = new WC_Order( $order_id );

			return [
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( true ),
			];
		}

		public function receipt_page( $order_id ) {
			echo '<p>' . __( 'Thanks you for order, press button to pay.', 'vepay' ) . '</p>';
			echo $this->generate_form( $order_id );
		}

		public function callback() {
			$extId  = $_GET['extid'];
			$id     = $_GET['id'];
			$sum    = $_GET['sum'];
			$status = $_GET['status'];
			$key    = $_GET['key'];

			$order = new WC_Order( $extId );

			$checkKey = md5( $extId . $id . $sum . $status . $this->callback_token );
			if ( $checkKey === $key ) {
				if ( intval( $status ) === 1 ) {
					$order->payment_complete();
				} else {
					$order->update_status( 'canceled', __( 'Payment error' ), 'vepay' );
				}
			} else {
				$order->update_status( 'failed', __( 'Checksum error' ), 'vepay' );
			}

			header( 'Content-type:application/json; Charset=utf-8' );
			echo json_encode( [ 'result' => true ] );
		}

		private function makeRequest( $url, $postData, $id, $token ) {
			$curl = curl_init();

			curl_setopt( $curl, CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $curl, CURLOPT_POSTFIELDS, $postData );
			curl_setopt( $curl, CURLOPT_CUSTOMREQUEST, 'POST' );
			curl_setopt( $curl, CURLOPT_URL, $url );
			curl_setopt( $curl, CURLOPT_HEADER, false );
			curl_setopt( $curl, CURLOPT_HTTPHEADER, [
				'Content-Type: application/json',
				'Accept: application/json',
				'X-Login: ' . $id,
				'X-Token: ' . $token
			] );
			curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );

			$response = curl_exec( $curl );

			curl_close( $curl );

			return json_decode( $response, true );
		}
	}

	function add_vepay_gateway( $methods ) {
		$methods[] = 'WC_VEPAY';

		return $methods;
	}

	add_filter( 'woocommerce_payment_gateways', 'add_vepay_gateway' );
}
